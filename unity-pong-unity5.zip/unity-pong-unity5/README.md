# Unity Ping Pong  
A simple game designed in unity.
---
The main functionality of this program is divided into four sub programs written in C#.  
1. BallControl
2. SideWalls
3. Playercontols
4. GameManager
---
The game is developed by 