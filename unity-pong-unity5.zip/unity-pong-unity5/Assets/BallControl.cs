﻿// The program to control ball
// author: 
// author_email:

// imports
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Ballcontrol class
public class BallControl : MonoBehaviour {

	private Rigidbody2D rb2d;
	private Vector2 vel;

	void GoBall() {
		// Method for random positioning of ball
		float rand = Random.Range (0, 2);
		if (rand < 1) {
			rb2d.AddForce (new Vector2 (20, -15));
		} else {
			rb2d.AddForce (new Vector2 (-20, -15));
		}
	}

	void Start () {
		// Method for initialization
		rb2d = GetComponent<Rigidbody2D> ();
		Invoke ("GoBall", 2);
	}

	void ResetBall() {
		// Method for reset ball position
		vel = new Vector2 (0, 0);
		rb2d.velocity = vel;
		transform.position = Vector2.zero;
	}

	void RestartGame() {
		// Method for restarting game
		ResetBall ();
		Invoke ("GoBall", 1);
	}

	void OnCollisionEnter2D(Collision2D coll) {
		if (coll.collider.CompareTag ("Player")) {
			vel.x = rb2d.velocity.x;
			vel.y = (rb2d.velocity.y / 2.0f) + (coll.collider.attachedRigidbody.velocity.y / 3.0f);
			rb2d.velocity = vel;
		}
	}

}
